from setuptools import setup, find_packages

setup(
    name='solidwrap.py',
    version='1.0',
    packages=find_packages(),
    package_data={
        # Include all files in the 'subfolder' directory
        'solidwrap.py': ['rsc/**'],
    },
    install_requires=[
        # List any dependencies your module requires
    ]
)