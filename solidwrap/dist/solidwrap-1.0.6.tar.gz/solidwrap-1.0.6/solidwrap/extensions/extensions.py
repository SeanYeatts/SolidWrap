"""
Copyright (c) 2023 Sean Yeatts. All rights reserved.
"""

# Import definition
__all__ = [
    "Extension"
]

# Base class for building extensions
class Extension:
    pass
