"""
Copyright (c) 2023 Sean Yeatts. All rights reserved.
"""

class Extension:
    pass
